package com.example.namebattler_ver00.GameSystem;

public class Poisen extends Magic{

	public Poisen(final String magicName, final int magicCost) {
		super(magicName, magicCost);
	}

}
