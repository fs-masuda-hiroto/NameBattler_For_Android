package com.example.namebattler_ver00.GameSystem;

public class Thunder extends Magic{

	public Thunder(final String magicName, final int magicCost) {
		super(magicName, magicCost);
	}
}
