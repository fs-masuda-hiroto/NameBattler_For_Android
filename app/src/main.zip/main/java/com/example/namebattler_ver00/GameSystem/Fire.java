package com.example.namebattler_ver00.GameSystem;

public class Fire extends Magic{

	public Fire(final String magicName, final int magicCost) {
		super(magicName, magicCost);
	}

}
