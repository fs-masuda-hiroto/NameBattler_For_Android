package com.example.namebattler_ver00.GameSystem;

public interface StrategyBase {

	 int getStrategy(Party targetParty);

}
